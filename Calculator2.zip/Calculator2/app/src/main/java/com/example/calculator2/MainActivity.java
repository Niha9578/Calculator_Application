package com.example.calculator2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText ViewDisplay;
    Button btnClear, btnPercent, btnDivide, btnMultiply, btnSubtract, btnAdd, btnEquals, btnDot, sqrt;
    Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;

    private double runningTotal = 0;
    private String operator = "+";
    private boolean isNewOperation = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewDisplay = findViewById(R.id.ViewDisplay);
        btnClear = findViewById(R.id.btnClear);
        btnPercent = findViewById(R.id.btnPercent);
        btnEquals = findViewById(R.id.btnEquals);
        btnDot = findViewById(R.id.btnDot);
        btnDivide = findViewById(R.id.btnDivide);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnAdd = findViewById(R.id.btnAdd);
        sqrt = findViewById(R.id.sqrt); // Initialize the square root button
        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);

        // Set up listeners for number buttons
        btn0.setOnClickListener(v -> appendNumber("0"));
        btn1.setOnClickListener(v -> appendNumber("1"));
        btn2.setOnClickListener(v -> appendNumber("2"));
        btn3.setOnClickListener(v -> appendNumber("3"));
        btn4.setOnClickListener(v -> appendNumber("4"));
        btn5.setOnClickListener(v -> appendNumber("5"));
        btn6.setOnClickListener(v -> appendNumber("6"));
        btn7.setOnClickListener(v -> appendNumber("7"));
        btn8.setOnClickListener(v -> appendNumber("8"));
        btn9.setOnClickListener(v -> appendNumber("9"));

        // Set up listeners for operators
        btnAdd.setOnClickListener(v -> setOperation("+"));
        btnSubtract.setOnClickListener(v -> setOperation("-"));
        btnMultiply.setOnClickListener(v -> setOperation("*"));
        btnDivide.setOnClickListener(v -> setOperation("/"));
        btnPercent.setOnClickListener(v -> calculatePercentage());
        btnDot.setOnClickListener(v -> appendDot());

        // Square root button listener
        sqrt.setOnClickListener(v -> calculateSquareRoot());

        // Equals and Clear button listeners
        btnEquals.setOnClickListener(v -> calculateResult());
        btnClear.setOnClickListener(v -> clearDisplay());
    }

    private void appendNumber(String number) {
        if (isNewOperation) {
            ViewDisplay.setText(number);
            isNewOperation = false;
        } else {
            ViewDisplay.append(number);
        }
    }

    private void appendDot() {
        if (isNewOperation) {
            ViewDisplay.setText("0.");
            isNewOperation = false;
        } else if (!ViewDisplay.getText().toString().contains(".")) {
            ViewDisplay.append(".");
        }
    }

    private void setOperation(String op) {
        performCurrentOperation();
        operator = op;
        isNewOperation = true;
    }

    private void calculateResult() {
        performCurrentOperation();
        ViewDisplay.setText(formatNumber(runningTotal));
        isNewOperation = true;
    }

    private void performCurrentOperation() {
        double currentNumber;
        try {
            currentNumber = Double.parseDouble(ViewDisplay.getText().toString());
        } catch (NumberFormatException e) {
            ViewDisplay.setText("Error");
            isNewOperation = true;
            return;
        }

        switch (operator) {
            case "+":
                runningTotal += currentNumber;
                break;
            case "-":
                runningTotal -= currentNumber;
                break;
            case "*":
                runningTotal *= currentNumber;
                break;
            case "/":
                if (currentNumber != 0) {
                    runningTotal /= currentNumber;
                } else {
                    ViewDisplay.setText("Error");
                    isNewOperation = true;
                    return;
                }
                break;
            default:
                runningTotal = currentNumber;
                break;
        }
    }

    private void calculatePercentage() {
        double currentNumber;
        try {
            currentNumber = Double.parseDouble(ViewDisplay.getText().toString());
        } catch (NumberFormatException e) {
            ViewDisplay.setText("Error");
            isNewOperation = true;
            return;
        }

        runningTotal = currentNumber / 100;
        ViewDisplay.setText(formatNumber(runningTotal));
        isNewOperation = true;
    }

    private void calculateSquareRoot() {
        double currentNumber;
        try {
            currentNumber = Double.parseDouble(ViewDisplay.getText().toString());
        } catch (NumberFormatException e) {
            ViewDisplay.setText("Error");
            isNewOperation = true;
            return;
        }

        if (currentNumber >= 0) {
            runningTotal = Math.sqrt(currentNumber);
            ViewDisplay.setText(formatNumber(runningTotal));
        } else {
            ViewDisplay.setText("Error"); // Error for negative numbers
        }
        isNewOperation = true;
    }

    private void clearDisplay() {
        ViewDisplay.setText("0");
        runningTotal = 0;
        operator = "+";
        isNewOperation = true;
    }

    private String formatNumber(double number) {
        if (number == (long) number)
            return String.format("%d", (long) number);
        else
            return String.format("%s", number);
    }
}
